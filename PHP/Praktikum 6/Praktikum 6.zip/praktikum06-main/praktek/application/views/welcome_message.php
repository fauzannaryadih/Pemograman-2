<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Selamat Datang</title>

</head>
<body>

<div id="container">
	<h1>SEMANGAT BELAJAR</h1>

	<div id="body">
		<p>JANGAN LUPA BERDOA SEBELUM BELAJAR</p>
	</div>
</div>

</body>
</html>
